import React from 'react';
import {Link} from 'react-router-dom';

const Nav = _ =>(
    <nav className="al-nav">
        <ul className="al-nav__wrap al-flex__wrap">
            <li className="al-nav__item al-flex__item">
                <Link to="/">
                    <i className="al-icon al-icon__home"></i>
                    <span className="al-nav__text">首页</span>
                </Link>
            </li>
            <li className="al-nav__item al-flex__item">
                <Link to="/member">
                    <i className="al-icon al-icon__app"></i>
                    <span className="al-nav__text">分类</span>
                </Link>
            </li>
            <li className="al-nav__item al-flex__item">
                <Link to="/module">
                    <i className="al-icon al-icon__shopcar"></i>
                    <span className="al-nav__text">购物车</span>
                </Link>
            </li>
            <li className="al-nav__item al-flex__item">
                <Link to="/product">
                    <i className="al-icon al-icon__my"></i>
                    <span className="al-nav__text">我的</span>
                </Link>
            </li>
        </ul>
    </nav>
)

export default Nav