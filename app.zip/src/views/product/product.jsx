import asyncCom from '../../utils/asyncCom';
import React from 'react';
import {Route, Link } from 'react-router-dom';

const ProductItem = asyncCom(_ => import('./product-item'));

const Product = ({match}) => (
    <div className="al-product">
        产品信息模版
        <ul className="al-product__wrap">
            <li className="al-product__item">
                <Link to={`${match.url}/product_item1`}>西瓜啊</Link>
            </li>
            <li className="al-product__item">
                <Link to={`${match.url}/product_item2`}>苹果啊</Link>
            </li>
            <li className="al-product__item">
                <Link to={`${match.url}/product_item3`}>菠萝啊</Link>
            </li>
        </ul>
        <Route path={`${match.url}/:id`} component={ProductItem} />
    </div>
);

export default Product