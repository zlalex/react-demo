import React from 'react';

const Module = _ => (
    <div className="al-setting">
        设置模版
    </div>
);

export default Module