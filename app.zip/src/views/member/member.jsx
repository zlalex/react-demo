import React from 'react';

const Member = _ => (
    <div className="al-member">
        个人中心模版
    </div>
);

export default Member