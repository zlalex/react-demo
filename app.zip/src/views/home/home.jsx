import React from 'react';

const Home = _ =>(
    <div>首页内容</div>
)

export default Home